package com.redcraft.communication.fields;

public enum GFieldCommunicationType {
    ALL,
    SELF,
    OTHERS,
    NONE
}
