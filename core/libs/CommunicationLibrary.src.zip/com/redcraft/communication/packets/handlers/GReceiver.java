package com.redcraft.communication.packets.handlers;

public interface GReceiver {
}
