package com.redcraft.communication.exceptions;

public class ChannelNotConnectedException extends CommunicationException {
}
