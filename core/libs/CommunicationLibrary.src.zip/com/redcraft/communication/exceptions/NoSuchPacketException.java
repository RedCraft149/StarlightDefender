package com.redcraft.communication.exceptions;

public class NoSuchPacketException extends CommunicationException {

}
