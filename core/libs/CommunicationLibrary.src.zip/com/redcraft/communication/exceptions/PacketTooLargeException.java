package com.redcraft.communication.exceptions;

public class PacketTooLargeException extends CommunicationException{
}
