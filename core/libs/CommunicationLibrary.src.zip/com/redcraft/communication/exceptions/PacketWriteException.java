package com.redcraft.communication.exceptions;

public class PacketWriteException extends CommunicationException{
}
