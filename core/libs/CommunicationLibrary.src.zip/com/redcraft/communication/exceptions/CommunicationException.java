package com.redcraft.communication.exceptions;

public class CommunicationException extends Exception {
}
