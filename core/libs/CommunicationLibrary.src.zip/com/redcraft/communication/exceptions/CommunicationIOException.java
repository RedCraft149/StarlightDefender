package com.redcraft.communication.exceptions;

public class CommunicationIOException extends CommunicationException {
}
